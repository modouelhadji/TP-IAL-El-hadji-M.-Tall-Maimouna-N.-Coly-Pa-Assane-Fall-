<?php
	/**
	 * Classe métier représentant une catégorie
	 */
	class Categorie
	{
		public $id;
		public $libelle;

		function __construct()
		{
			
		}
	}
?>