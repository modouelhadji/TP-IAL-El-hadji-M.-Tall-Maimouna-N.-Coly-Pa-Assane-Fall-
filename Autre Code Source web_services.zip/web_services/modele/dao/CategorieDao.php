<?php
	require_once 'ConnexionManager.php';

	/**
	 * Classe de gestion des accès aux articles
	 */
	class CategorieDao
	{
		//private $id;
		//private $bdd;
		//private $libelle;

		public function __construct()
		{
			$this->bdd = (new ConnexionManager)->getInstance();
		}

		public function getList()
		{
			$reponse = $this->bdd->query('SELECT * FROM categorie');
			$data = $reponse->fetchAll(PDO::FETCH_CLASS, 'Categorie');
			// $reponse->closeCursor();
			return $data;
		}

		/*public function getById($id)
		{
			$reponse = $this->bdd->query('SELECT * FROM categorie WHERE id = '.$id);
			$data = $reponse->fetch(PDO::FETCH_OBJ);
			// $reponse->closeCursor();
			return $data;
		}*/

		public function delCategory($id)
		{
			$res = $this->bdd->exec('DELETE FROM categorie WHERE id = '.$id);
			return $res;
		}

		public function modCategory($lib, $id)
		{
			$sql = "UPDATE categorie SET libelle=? WHERE id=?";
			$res = $this->bdd->prepare($sql)->execute([$lib, $id]);
			return $res;
		}

		public function addCategory($lib)
		{
			$sql = "INSERT INTO categorie (libelle) VALUES (?)";
			$res = $this->bdd->prepare($sql)->execute([$lib]);
			return $res;
		}

	}
?>
