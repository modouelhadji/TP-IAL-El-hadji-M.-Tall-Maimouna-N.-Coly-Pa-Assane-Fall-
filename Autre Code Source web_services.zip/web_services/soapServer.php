<?php

require_once('./nusoap-0/lib/nusoap.php');
require ('./modele/dao/UsersDao.php');

$serveur=new soap_server();
$serveur->configureWSDL('serveur', 'urn:serveur');


$serveur-> register('UsersDao.getList', array(), array('return' => 'xsd:arrays'));

$serveur-> register('UsersDao.addUser', array('usn' => 'xsd:string', 'pwd' => 'xsd:string','type' => 'xsd:string'), array('return' => 'xsd:int'));

$serveur-> register('UsersDao.delUser', array('usn' => 'xsd:string'), array('return' => 'xsd:int'));

$serveur-> register('UsersDao.modUser', array('usn' => 'xsd:string', 'pwd' => 'xsd:string','type' => 'xsd:string'), array('return' => 'xsd:int'));

$serveur-> register('UsersDao.userLogin', array('usn' => 'xsd:string', 'pwd' => 'xsd:string'), array('return' => 'xsd:int'));


$HTTP_RAW_POST_DATA = isset($HTTP_RAW_POST_DATA) ? $HTTP_RAW_POST_DATA : '';
@$serveur -> service(file_get_contents("php://input"));

?>