<?php
	include_once '../modele/dao/ConnexionManager.php';

	/**
	 * Classe de gestion des accès aux articles
	 */
	class ArticleDao
	{
		private $bdd;

		public function __construct()
		{
			$this->bdd = (new ConnexionManager)->getInstance();
		}

		public function getList()
		{
			$data = $this->bdd->query('SELECT * FROM article');
			return $data;
		}

		public function getByCategorie()
		{
			$data = $this->bdd->query("SELECT * FROM article a LEFT JOIN article b ON a.Categorie = b.id ORDER BY a.categorie DESC");
			return $data;
		}

		public function getByCategoryId($id)
		{
			$data = $this->bdd->query('SELECT * FROM article WHERE categorie = '.$id);
			return $data;
		}

	}
	// $a = new ArticleDao();
	// $b = $a->getByCategoryId('1');
	// echo json_encode($b);
?>
