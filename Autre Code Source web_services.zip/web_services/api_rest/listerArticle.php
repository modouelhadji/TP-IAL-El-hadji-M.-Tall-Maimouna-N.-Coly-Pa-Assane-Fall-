<?php
header("Access-Control-Allow-Origin: *");
header("Content-Type: application/json; charset=UTF-8");
header("Content-Type: application/xml; charset=UTF-8");
header("Access-Control-Allow-Methods: GET");
header("Access-Control-Max-Age: 4000");
header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Request-With");

if($_SERVER['REQUEST_METHOD'] == 'GET'){
    
    include_once 'test1.php';
    include_once '../modele/dao/ConnexionManager.php';

    
    $bdd = new ConnexionManager();
    $db = $bdd->getInstance();

    
    $articles = new ArticleDao($db);

    
    $stmt = $articles->getList();

    //verifier s'il y a des articles dans la base de donnees
    if($stmt->rowCount() > 0){
        $format = $_GET["format"];
        // 
        $listeArticles = array();
        $listeArticles["art"] = array();

        // 
            while($row = $stmt->fetch(PDO::FETCH_ASSOC)){
                extract($row);

                $prod = array(
                    "id" => $id,
                    "titre" => $titre,
                    "contenu" => $contenu,
                    "categorie" => $categorie,
                    "dateCreation" => $dateCreation,
                    "dateModification" => $dateModification
                );


                array_push($listeArticles["art"], $prod);
            }
        
        http_response_code(200);

        //si le format xml a ete choisi 
        if($format =="XML"){
            $xml =new SimpleXmlElement('<racine/>');

            $element_xml=$xml->addChild('article');

            foreach ($listeArticles as $article) {

                foreach ($article as $attribut) {

                    $element_xml->addChild('id',$attribut['id']);
                    $element_xml->addChild('titre',$attribut['titre']);
                    $element_xml->addChild('contenu',$attribut['contenu']);
                    $element_xml->addChild('categorie',$attribut['categorie']);
                    $element_xml->addChild('dateCreation',$attribut['dateCreation']);
                    $element_xml->addChild('dateModification',$attribut['dateModification']);

                }
              
            }
            echo $xml->asXML();
        }

        //si le format json est choisi
        if($format =="JSON"){
            echo json_encode($listeArticles);
        }

    //il n'y a pas d'articles dans la base de donnees
    }else{
        echo json_encode(["message" => "Pas d'articles trouvés"]);
    }
    

}else{
    // Mauvaise méthode, on gère l'erreur
    http_response_code(405);
    echo json_encode(["message" => "La méthode n'est pas autorisée"]);
}