<?php
	require 'controleur/Controller.php';
	$controller = new Controller();

	if (isset($_POST['usna'])) {
		$controller->addUser($_POST['usna'], $_POST['pwd'], $_POST['type']);
		header("Location: index.php?action=listus");
	}
	if (isset($_POST['usn'])) {
		$controller->userLogin($_POST['usn'], $_POST['pwd']);
	}
	if (isset($_POST['usnm'])) {
		$controller->modUser($_POST['usnm'], $_POST['pwd'], $_POST['type'], $_POST['cible']);
		header("Location: index.php?action=listus");
	}
	if (isset($_POST['ttr'])) {
		$controller->addArticle($_POST['ttr'], $_POST['ctn'], $_POST['cat']);
	}
	if (isset($_POST['ttrm'])) {
		$controller->modArticle($_POST['ttrm'], $_POST['ctn'], $_POST['cat'], $_POST['id']);
	}
	if (isset($_POST['lbl'])) {
		$controller->addCategory($_POST['lbl']);
	}
	if (isset($_POST['lblm'])) {
		$controller->modCategory($_POST['lblm'], $_POST['id']);
	}
	$cnt = $controller->articleCount();
	$pg=0;
	if (isset($_GET['p']))
		if (is_numeric($_GET['p']))
			$pg = $_GET['p'];



	if (!isset($_GET['action']))
	{
		$controller->showAccueil($cnt,$pg);
	}
	else
	{
		if (strtolower($_GET['action']) === 'article')
		{
			if (isset($_GET['id']))
			{
				$controller->showArticle($_GET['id']);
			}
			else
			{
				$controller->ShowErrorPage();
			}
		}
		else if (strtolower($_GET['action']) === 'categorie')
		{
			if (isset($_GET['id']))
			{
				$controller->showCategorie($_GET['id']);
			}
			else
			{
				$controller->ShowErrorPage();
			}
		}
		else {
			if (strtolower($_GET['action']) === 'adduser' || strtolower($_GET['action']) === 'listus' || strtolower($_GET['action']) === 'moduser' || strtolower($_GET['action']) === 'deluser' ||  strtolower($_GET['action']) === 'addcategory'
			|| strtolower($_GET['action']) === 'modcategory' || strtolower($_GET['action']) === 'delcategory' || strtolower($_GET['action']) === 'addarticle' || strtolower($_GET['action']) === 'modarticle' ||
			strtolower($_GET['action']) === 'delarticle' || strtolower($_GET['action']) === 'dec' || strtolower($_GET['action']) === 'co') {
				if (strtolower($_GET['action']) === 'adduser')
					$controller->showUserAddPage();
				if (strtolower($_GET['action']) === 'listus')
					$controller->showUsers();
				if (strtolower($_GET['action']) === 'moduser')
					$controller->showUserModPage($_GET['usn']);
				if (strtolower($_GET['action']) === 'deluser') {
					$controller->delUser($_GET['usn']);
					$controller->showUsers();
				}
				if (strtolower($_GET['action']) === 'addcategory')
					$controller->showCategoryAddPage();
				if (strtolower($_GET['action']) === 'modcategory')
					$controller->showCategoryModPage($_GET['id']);
				if (strtolower($_GET['action']) === 'delcategory') {
					$controller->delCategory($_GET['id']);
					$controller->showAccueil($cnt,$pg);;
				}
				if (strtolower($_GET['action']) === 'addarticle')
					$controller->showArticleAddPage();
				if (strtolower($_GET['action']) === 'modarticle')
					$controller->showArticleModPage($_GET['id']);
				if (strtolower($_GET['action']) === 'delarticle') {
					$controller->delArticle($_GET['id']);
					$controller->showAccueil($cnt,$pg);;
				}
				if (strtolower($_GET['action']) === 'dec')
					$controller->userLogout();
				if (strtolower($_GET['action']) === 'co')
					$controller->showLoginPage();
				}
				else
					$controller->showAccueil($cnt,$pg);
		}
	}

?>
