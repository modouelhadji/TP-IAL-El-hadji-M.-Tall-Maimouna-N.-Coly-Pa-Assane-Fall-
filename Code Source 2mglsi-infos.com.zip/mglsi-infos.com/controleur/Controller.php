<?php
	require_once 'modele/dao/ArticleDao.php';
	require_once 'modele/dao/CategorieDao.php';
	require_once 'modele/dao/UsersDao.php';
	require_once 'modele/domaine/Article.php';
	require_once 'modele/domaine/Categorie.php';
	require_once 'modele/domaine/Users.php';
	session_start();
	/**
	 * Classe représentant notre controleur principal
	 */

	class Controller
	{

		function __construct()
		{

		}

		public function showAccueil($cnt,$pg) {
			$articleDao = new ArticleDao();
			$categorieDao = new CategorieDao();

			$articles = $articleDao->getList();
			$categories = $categorieDao->getList();
			require_once 'vue/accueil.php';
		}

		public function showUsers() {
			$usersDao = new UsersDao();
			$categorieDao = new CategorieDao();

			$categories = $categorieDao->getList();
			$users = $usersDao->getList();
			require_once 'vue/users.php';
		}

		public function showLoginPage() {
			$usersDao = new UsersDao();
			$categorieDao = new CategorieDao();
			$categories = $categorieDao->getList();
			require_once 'vue/login.php';
		}

		public function showUserAddPage() {
			$categorieDao = new CategorieDao();
			$categories = $categorieDao->getList();
			require_once 'vue/useradd.php';
		}

		public function showUserModPage($usn) {
			$categorieDao = new CategorieDao();
			$usersDao = new UsersDao();

			$categories = $categorieDao->getList();
			$user = $usersDao->getList();
			require_once 'vue/usermod.php';
		}

		public function showArticle($id) {
			$articleDao = new ArticleDao();
			$categorieDao = new CategorieDao();
			$usersDao = new UsersDao();

			$article = $articleDao->getById($id);
			$categories = $categorieDao->getList();
			require_once 'vue/article.php';
		}

		public function showArticleModPage($id) {
			$categorieDao = new CategorieDao();

			$categories = $categorieDao->getList();
			require_once 'vue/articlemod.php';
		}

		public function showCategorie($id) {
			$articleDao = new ArticleDao();
			$categorieDao = new CategorieDao();

			$articles = $articleDao->getByCategoryId($id);
			$categories = $categorieDao->getList();
			require_once 'vue/articleByCategorie.php';
		}

		public function showArticleAddPage() {
			$categorieDao = new CategorieDao();

			$categories = $categorieDao->getList();
			require_once 'vue/articleadd.php';
		}

		public function showCategoryAddPage() {
			$categorieDao = new CategorieDao();

			$categories = $categorieDao->getList();
			require_once 'vue/categoryadd.php';
		}

		public function showCategoryModPage($id) {
			$categorieDao = new CategorieDao();

			$categories = $categorieDao->getList();
			require_once 'vue/categorymod.php';
		}

		public function addUser($usn, $pwd, $type) {
			$usersDao = new UsersDao();

			return $usersDao->addUser($usn, $pwd, $type);
		}

		public function delUser($usn) {
			$usersDao = new UsersDao();

			return $usersDao->delUser($usn);
		}

		public function modUser($usn, $pwd, $type, $cible) {
			$usersDao = new UsersDao();

			return $usersDao->modUser($usn, $pwd, $type, $cible);
		}

		public function userLogin($usn, $pwd) {
			$usersDao = new UsersDao();

			$loginRes = $usersDao->userLogin($usn, $pwd);
			if ($loginRes) {
				$_SESSION['usn'] = $usn;
				$_SESSION['type'] = $usersDao->userType($usn);
				return $loginRes;
			}
			return $loginRes;
		}

		public function userLogout() {
				session_unset();
        session_destroy();
        header("Location: index.php");
		}

		public function userType($usn) {
			$usersDao = new UsersDao();

			$loginRes = $usersDao->userType($usn);
			return $loginRes;
		}

		public function articleCount() {
			$articleDao = new ArticleDao();

			return $articleDao->getCount($titre, $contenu, $categorie);
		}

		/*public function userPwd($usn) {
			$usersDao = new UsersDao();

			return $usersDao->userPwd($usn);
		}*/

		public function addArticle($titre, $contenu, $categorie) {
			$articleDao = new ArticleDao();

			return $articleDao->addArticle($titre, $contenu, $categorie);
		}

		public function modArticle($titre, $contenu, $categorie, $id) {
			$articleDao = new ArticleDao();

			return $articleDao->modArticle($titre, $contenu, $categorie, $id);
		}

		public function delArticle($id) {
			$articleDao = new ArticleDao();

			return $articleDao->delArticle($id);
		}

		public function addCategory($lbl) {
			$categorieDao = new CategorieDao();
			return $categorieDao->addCategory($lbl);
		}

		public function modCategory($lib, $id) {
			$categorieDao = new CategorieDao();
			return $categorieDao->modCategory($lib, $id);
		}

		public function delCategory($id) {
			$categorieDao = new CategorieDao();
			return $categorieDao->delCategory($id);
		}



	}
?>
