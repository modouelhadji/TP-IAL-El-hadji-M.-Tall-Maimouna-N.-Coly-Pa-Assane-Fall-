<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<title>Actualités MGLSI</title>
	<link rel="stylesheet" type="text/css" href="assets/css/style.css">
</head>
<body>
	<?php require_once 'inc/entete.php'; ?>
	<div id="contenu">
		<?php if (!empty($articles)):
			$cursor=$pg;
			 foreach ($articles as $article):
							if ($cursor>0) {
								$cursor=$cursor-1;
								continue;
								}?>
				<div class="article">
					<h1><a href="index.php?action=article&id=<?= $article->id ?>"><?= $article->titre ?></a></h1>
					<p><?= substr($article->contenu, 0, 300) . '...' ?></p>
					<? if (isset($_SESSION['usn']))  {?><p><a href="index.php?action=delarticle&id=<?= $article->id ?>"> Supprimer </a>&nbsp<a href="index.php?action=modarticle&id=<?= $article->id ?>"> Modifier </a></p>
			<?php } ?> </div> <? break; endforeach ?><p><? $suiv=$pg+1; $prec=$pg-1; if($pg>0) { ?><a href="index.php?p=<? echo $prec; ?>"> Précédent </a><? } ?>&nbsp<?
			if ($suiv<$cnt) { ?><a href="index.php?p=<? echo $suiv; ?>"> Suivant </a><? } ?></p>
		<?php else: ?>
			<div class="message">Aucun article trouvé</div>
		<?php endif; ?>
	</div>
	<?php
		echo $cnt;
		require_once 'inc/menu.php';
	?>
</body>
</html>
