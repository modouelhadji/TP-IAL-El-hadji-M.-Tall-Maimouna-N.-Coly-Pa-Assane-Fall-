<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<title>Actualités MGLSI</title>
	<link rel="stylesheet" type="text/css" href="assets/css/style.css">
</head>
<body>
	<?php require_once 'inc/entete.php'; ?>
	<div id="contenu">
		<?php if (!empty($users)): ?>
			<?php foreach ($users as $user): ?>
				<div class="article">
					<p><h1>Nom d'utilisateur : <?= $user->usn ?></h1>
					<br>Mot de passe : <?= $user->pwd ?>
          <br>Type :<?= $user->type ?></p>
          <p><a href="index.php?action=deluser&usn=<?= $user->usn ?>"> Supprimer </a>&nbsp<a href="index.php?action=moduser&usn=<?= $user->usn ?>"> Modifier </a></p>
				</div>

			<?php endforeach ?>
		<?php else: ?>
			<div class="message">Aucun utilisateur trouvé</div>
		<?php endif ?>
	</div>
  <? 
  require_once 'inc/menu.php';
?>
</body>
</html>
