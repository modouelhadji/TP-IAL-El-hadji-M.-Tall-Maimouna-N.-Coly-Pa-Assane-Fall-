<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<title>Actualités MGLSI</title>
	<link rel="stylesheet" type="text/css" href="assets/css/style.css">
</head>
<body>
<?php require_once 'inc/entete.php'; ?>
            <h2 id="title">Formulaire de connexion</h2>
            <form action="index.php?p" method="post">
              <input  type="text" class="validate" name="usn">
              <label for="username">Nom d'utilisateur</label><br>
              <input  type="password" class="validate" name="pwd">
              <label for="password">Mot de passe</label>
            <br><br>
        <button type="submit" class="waves-effect waves-light btn" id="loginbtn">Se connecter</button>
      </form>
<? require_once 'inc/menu.php';  ?>
</body>
</html>
