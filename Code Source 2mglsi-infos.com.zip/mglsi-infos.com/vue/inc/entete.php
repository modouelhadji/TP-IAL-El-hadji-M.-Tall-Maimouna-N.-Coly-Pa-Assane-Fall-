<div id="entete">
	<h1>Site d'actualités du MGLSI</h1>
	<!-- <hr> -->
</div>
