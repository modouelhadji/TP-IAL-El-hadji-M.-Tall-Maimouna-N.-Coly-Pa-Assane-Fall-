<div id="menu">
	<h1>Catégories</h1><hr width="20%">
	<ul>
		<li><a href="index.php"><h2>Tout</h2></a></li>
		<?php foreach ($categories as $categorie): ?>
			<li>
				<a href="index.php?action=categorie&id=<?= $categorie->id ?>"><h2><?= $categorie->libelle ?></h2></a>
				<? if (isset($_SESSION['usn']))  {?>
					<h6><a href="index.php?action=modcategory&id=<?= $categorie->id ?>">Modifier</a>
					<a href="index.php?action=delcategory&id=<?= $categorie->id ?>">Supprimer</a></h6>
				<?php } ?>
			</li>
		<?php endforeach ?>
	</ul></br></br></br></br>
</div>

<div id="menu">
	<h1>Menu</h1><hr width="20%">
	<ul>
		<? if (isset($_SESSION['usn'])) {?>
		<li>
			<a href="index.php?action=addarticle">Ajouter article</a>
		</li>
		<li>
			<a href="index.php?action=addcategory">Ajouter catégorie</a>
		</li>
		<? if($_SESSION['type']==='admin') { ?>
		<li>
			<a href="index.php?action=listus">Lister utilisateurs</a>
		</li>
		<li>
			<a href="index.php?action=adduser">Ajouter utilisateur</a>
		</li>
		<? }} ?>
		<li>
			<a href="index.php?action=<? if (isset($_SESSION['usn'])) echo "dec"; else echo "co"; ?>"><? if (isset($_SESSION['usn'])) echo "Se déconnecter"; else echo "Se connecter"; ?></a>
		</li>
	</ul>
</div>
