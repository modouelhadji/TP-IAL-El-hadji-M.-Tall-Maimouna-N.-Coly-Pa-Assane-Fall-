<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<title>Actualités MGLSI</title>
	<link rel="stylesheet" type="text/css" href="assets/css/style.css">
</head>
<body>
<?php require_once 'inc/entete.php'; ?>
<div class="container">
    <div class="row">

        <div class="col s6 offset-s3 z-depth-1" id="panell">
            <h5 id="title">Formulaire de modification d'un article</h5>
            <form action="index.php" method="post">

            <div class="input-field" id="username">
              <input  type="hidden" value="<? echo $id; ?>" class="validate" name="id">
              <input  type="text" class="validate" name="ttrm">
              <label for="ttr">Titre</label>
          </div>
          <div class="input-field" id="username">
            <input  type="text" class="validate" name="ctn">
            <label for="ctn">Contenu</label>
          </div>
          <div class="input-field" id="usn">
            <select name="cat">
              <?php foreach ($categories as $categorie): ?>
                <option value="<? echo $categorie->id; ?>" selected><? echo $categorie->libelle; ?></option>
        				 <? endforeach ?>
            </select>
            <label for="text">Catégorie</label>
          </div>
        <button type="submit" class="waves-effect waves-light btn" id="loginbtn">Modifier</button>
      </form>
      </div>
    </div>
    <? require_once 'inc/menu.php'; ?>
</div>
</body>
</html>
