<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<title>Actualités MGLSI</title>
	<link rel="stylesheet" type="text/css" href="assets/css/style.css">
</head>
<body>
<?php require_once 'inc/entete.php'; ?>
<div class="container">
    <div class="row">

        <div class="col s6 offset-s3 z-depth-1" id="panell">
            <h2 id="title">Formulaire de modification d'un utilisateur</h2>
            <form action="index.php" method="post">

            <div class="input-field" id="username">
							<input  type="hidden" value="<? echo $usn; ?>"class="validate" name="cible">
              <input  type="text" value="<? echo $usn; ?>" class="validate" name="usnm">
              <label for="username">Nom d'utilisateur</label>
          </div>
          <div class="input-field" id="password">
            <input  type="password" class="validate" name="pwd">
            <label for="password">Mot de passe</label>
          </div>
					<div class="input-field" id="usn">
	          <select name="type">
	            <option value="edit" selected>Éditeur</option>
	            <option value="admin">Adminitrateur</option>
	          </select>
	          <label for="text">Type</label>
	        </div>
        <button type="submit" class="waves-effect waves-light btn" id="loginbtn">Modifier</button>
      </form>
      </div>
    </div>
    <? require_once 'inc/menu.php'; ?>
</div>
</body>
</html>
