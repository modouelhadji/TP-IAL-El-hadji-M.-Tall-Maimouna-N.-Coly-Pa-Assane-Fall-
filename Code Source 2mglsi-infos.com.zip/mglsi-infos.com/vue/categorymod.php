<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<title>Actualités MGLSI</title>
	<link rel="stylesheet" type="text/css" href="assets/css/style.css">
</head>
<body>
<?php require_once 'inc/entete.php'; ?>
<div class="container">
    <div class="row">

        <div class="col s6 offset-s3 z-depth-1" id="panell">
            <h5 id="title">Formulaire de modification d'une catégorie</h5>
            <form action="index.php" method="post">

            <div class="input-field" id="username">
              <input  type="hidden" value="<? echo $id; ?>" class="validate" name="id">
              <input  type="text" class="validate" name="lblm">
              <label for="username">Libellé</label>
          </div>
        <button type="submit" class="waves-effect waves-light btn" id="loginbtn">Modifier</button>
      </form>
      </div>
    </div>
    <? require_once 'inc/menu.php'; ?>
</div>
</body>
</html>
