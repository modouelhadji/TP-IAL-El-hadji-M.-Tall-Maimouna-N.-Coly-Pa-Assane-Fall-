<?php
	require_once 'ConnexionManager.php';

	/**
	 * Classe de gestion des accès aux utilisateurs
	 */
	class UsersDao
	{
		private $usn;
		private $pwd;
    private $type;
    private $bdd;

		public function __construct()
		{
			$this->bdd = (new ConnexionManager)->getInstance();
		}

		public function getList()
		{
			$reponse = $this->bdd->query('SELECT * FROM users');
			$data = $reponse->fetchAll(PDO::FETCH_CLASS, 'Users');
			return $data;
		}

    public function addUser($usn, $pwd, $type)
		{
      $sql = "SELECT COUNT(usn) AS num FROM users WHERE usn = :usn";
      $stmt = $this->bdd->prepare($sql);
      $stmt->bindValue(':usn', $usn);
      $stmt->execute();
      $row = $stmt->fetch(PDO::FETCH_ASSOC);
      if($row['num'] > 0){
          return $res=0;
      }
      $pwdHash = password_hash($pwd, PASSWORD_BCRYPT, array("cost" => 12));
			$sql = "INSERT INTO users (usn, pwd, type) VALUES (?,?,?)";
			$res = $this->bdd->prepare($sql)->execute([$usn, $pwdHash, $type]);
			return $res=1;
		}

    public function delUser($usn)
		{
      $sql = "DELETE FROM users WHERE usn=?";
			//$res = $this->bdd->exec('DELETE FROM users WHERE usn = '.$usn);
      $res = $this->bdd->prepare($sql)->execute([$usn]);
			return $res;
		}

    public function modUser($usn, $pwd, $type, $cible)
		{
			$sql = "UPDATE users SET usn=?, pwd=?, type=? WHERE usn=?";
      $pwdHash = password_hash($pwd, PASSWORD_BCRYPT, array("cost" => 12));
			$res = $this->bdd->prepare($sql)->execute([$usn, $pwdHash, $type, $cible]);
			return $res;
		}

    /*public function userPwd($usn) {
      $sql = "SELECT usn, pwd FROM users WHERE usn = :usn";
      $stmt = $this->bdd->prepare($sql);

      $stmt->bindValue(':usn', $usn);
      $stmt->execute();
      $user = $stmt->fetch(PDO::FETCH_OBJ);
      return $user->pwd;
    }*/

    public function userType($usn) {
      $sql = "SELECT type FROM users WHERE usn = :usn";
      $stmt = $this->bdd->prepare($sql);

      $stmt->bindValue(':usn', $usn);
      $stmt->execute();
      $user = $stmt->fetch(PDO::FETCH_OBJ);
      return $user->type;
    }

    public function userLogin($usn, $pwd) {
      $sql = "SELECT usn, pwd FROM users WHERE usn = :usn";
      $stmt = $this->bdd->prepare($sql);

      $stmt->bindValue(':usn', $usn);
      $stmt->execute();
      $user = $stmt->fetch(PDO::FETCH_OBJ);
      if($user === false){
          return $res=0;
      } else {
          $validPassword = password_verify($pwd, $user->pwd);
          if($validPassword)
              return $res=1;
          else
              return $res=0;
          }
      }

      public function userGet($usn) {
        $sql = "SELECT usn, pwd FROM users WHERE usn = :usn";
        $stmt = $this->bdd->prepare($sql);

        $stmt->bindValue(':usn', $usn);
        $stmt->execute();
         return $user = $stmt->fetch(PDO::FETCH_OBJ);
      }
    }

?>
