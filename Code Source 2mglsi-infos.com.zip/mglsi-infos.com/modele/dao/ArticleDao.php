<?php
	require_once 'ConnexionManager.php';

	/**
	 * Classe de gestion des accès aux articles
	 */
	class ArticleDao
	{
		private $bdd;

		public function __construct()
		{
			$this->bdd = (new ConnexionManager)->getInstance();
		}

		public function getList()
		{
			$data = $this->bdd->query('SELECT * FROM article');
			return $data->fetchAll(PDO::FETCH_CLASS, 'Article');
		}

		public function getById($id)
		{
			$data = $this->bdd->query('SELECT * FROM article WHERE id = '.$id);
			return $data->fetch(PDO::FETCH_OBJ);
		}

		public function getCount()
		{
			$sql = 'SELECT COUNT(id) AS num FROM article';
			$stmt = $this->bdd->prepare($sql);
      $stmt->execute();
      $row = $stmt->fetch(PDO::FETCH_ASSOC);
			return $row['num'];
		}

		public function getByCategoryId($id)
		{
			$data = $this->bdd->query('SELECT * FROM article WHERE categorie = '.$id);
			return $data->fetchAll(PDO::FETCH_CLASS, 'Article');
		}

		public function addArticle($titre, $contenu, $categorie)
		{
			$sql = "INSERT INTO article (titre, contenu, categorie) VALUES (?,?,?)";
			$res = $this->bdd->prepare($sql)->execute([$titre, $contenu, $categorie]);
			return $res;
		}

		public function delArticle($id)
		{
			$res = $this->bdd->exec('DELETE FROM article WHERE id = '.$id);
			return $res;
		}

		public function modArticle($titre, $contenu, $categorie, $id)
		{
			$sql = "UPDATE article SET titre=?, contenu=?, categorie=? WHERE id=?";
			$res = $this->bdd->prepare($sql)->execute([$titre, $contenu, $categorie, $id]);
			return $res;
		}

	}
?>
