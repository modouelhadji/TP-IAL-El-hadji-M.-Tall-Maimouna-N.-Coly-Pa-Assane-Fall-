<?php
	/**
	 * Classe métier représentant un utilisateur
	 */
	class Users
	{
		public $usn;
    public $pwd;
		public $type;

		function __construct()
		{

		}
	}
?>
